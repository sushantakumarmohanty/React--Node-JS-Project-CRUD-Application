let User = require('../model/user.model')
module.exports.SignIn = async(req,res) => {
    try{
           let { email,username,password} = req.body
           let user = await User.find({email});
           if(!user){
            res.send({success:false,data:'User does not exist'})
           }
           if(!user[0].authenticate(password)){
            res.send({success:false,data:'Incorrect Password'})
           }else{
            res.send({success:true,data:`Welcome ${user.username}`})
           }


    }
    catch(error){

    }
}

