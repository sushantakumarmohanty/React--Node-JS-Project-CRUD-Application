let Trainee = require('../model/trainee.model');

module.exports.getTrainees = async (req,res ) =>{
    try{
           let trainees = await Trainee.find();
           res.send({ success:true,data:trainees}) 
    }
    catch(error){
        res.send({success:false,data:error.message});
    }
}
module.exports.createTrainee = async (req,res) =>{
    try{
        let { name,degree} = req.body;
        let trainee = new  Trainee({name,degree})
        let data = await trainee.save()
        res.send({success:true,data:`Trainee is created ${data}`});
    }
    catch(error){
        res.send({success:false,data:error.message});
    }
}
module.exports.deleteTrainee = async (req,res) => {
    try{
        const { id } = req.params;
        let trainee = await Trainee.findOne({_id:id});
        if(!trainee){
            res.send({success:false,data:'Trainee Does not exist'});
        }
        else{
        await Trainee.deleteOne({_id:id});
        res.send({success:true,data:'Tainee is deleted'});
        }
    }
    catch(error){
        res.send({success:false,data:error.message});
        
    }
}
module.exports.updateTrainee = async (req,res) => {
    try{
        const { id } = req.params;
        let trainee = await Trainee.findOne({_id:id});
        if(!trainee){
            res.send({success:false,data:'Trainee Does not exist'});
        }
        else{
            const { name,degree} = req.body
        await Trainee.updateOne({_id:id},{name,degree});
        res.send({success:true,data:'Tainee is updated'});
        }
    }
    catch(error){
        res.send({success:false,data:error.message});
        
    }
}
//router.delete('/delete/:id',TraineeController.deleteTrainee);