const User = require('../model/user.model');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();
module.exports.signUp = async (req,res) =>{
    try{
        const { username,email,password} = req.body;
        let user = new User({ username,email,password});
        let result = await user.save();
        res.send({success:true,data:result})
    }
    catch(error){
        res.send({ success:false,data:error.message});
    }
}
module.exports.signIn = async (req,res) =>{
    try{
        const { email,password} = req.body;
        let user = await User.findOne({email});
        if(!user){
            res.send({success:false,data:'User does not exist'});
        }
        else{
            if(!user.authenticate(password)){
                res.send({success:false,data:'Incorrect Password'})
            }else{
                const token = jwt.sign({username:user.username},process.env.ACCESS_TOKEN_SECRET);
                res.send({success:true,data:token});
                //res.send({success:true,data:`Welcome ${user.username}`});
            }
        }
    }
    catch(error){
        res.send({ success:false,data:error.message});
    }
}