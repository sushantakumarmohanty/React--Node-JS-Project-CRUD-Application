const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
dotenv.config();
module.exports.verifyToken =  async (req,res,next)  =>{
    const bearerHeader = req.headers['authorization'];
    if( typeof bearerHeader !== undefined){
        const berareArray = bearerHeader.split(' ');
        const bearerToken = berareArray[1];
        let decodedToken = jwt.verify(bearerToken,process.env.ACCESS_TOKEN_SECRET)
        console.log('Decoded Token is: ',decodedToken);
        req.params = { name:decodedToken.username};
        next();
    }
    else
    {
        res.status(403).send({success:false,data:'unauthenticated'});
    }
}