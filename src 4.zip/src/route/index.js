const express = require('express');
const TraineeRoutes = require('../route/trainee.route');
const UserRoutes = require('../route/user.route');
const AuthRoutes = require('../route/auth.route');
const router = express.Router();
router.use('/trainee',TraineeRoutes);
router.use('/user',UserRoutes);
router.use('/auth',AuthRoutes);

module.exports = router;