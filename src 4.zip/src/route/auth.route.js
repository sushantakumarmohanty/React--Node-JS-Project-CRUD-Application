const express = require('express');
const AuthController = require('../controller/auth.controller');
const router = express.Router();

router.get('/secureapi',AuthController.verifyToken,(req,res)=>{
    let { name} = req.params
    res.send({success:true,data:`Welcome ${name}`})
});
module.exports = router;