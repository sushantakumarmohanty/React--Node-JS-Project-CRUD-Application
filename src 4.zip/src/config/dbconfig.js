const mongoose = require('mongoose');
const detenv = require('dotenv');
detenv.config();
module.exports.MongoConnect = async function(){
    try{
          //await mongoose.connect('mongodb://127.0.0.1:27017/test')
          await mongoose.connect(process.env.DB_URL + '/' + process.env.DB_NAME);
          //await mongoose.connect(process.env.MONGO_URL);
          console.log('Database connection is done');
    }
    catch(error){
        console.log(error.message)
    }
}