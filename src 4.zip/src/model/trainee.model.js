const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let TraineeSchema = new Schema({
    name:{
        type:String
    },
    degree:{
        type:String
    }
});
let Trainee = mongoose.model('Trainee',TraineeSchema);
module.exports = Trainee;